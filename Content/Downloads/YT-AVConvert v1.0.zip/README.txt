RUN IN ADMINISTRATOR MODE!
Administrator mode is needed for proper function,
without it files will not be written in the system program files
and shortcuts wouldn't be able to be created.

YT-DLP
https://github.com/yt-dlp/yt-dlp

FFMPEG
https://github.com/FFmpeg/FFmpeg