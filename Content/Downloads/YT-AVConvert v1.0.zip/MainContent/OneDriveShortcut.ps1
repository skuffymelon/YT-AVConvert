$shell = New-Object -ComObject WScript.Shell
$shortcut = $shell.CreateShortcut("$env:USERPROFILE\OneDrive\Desktop\YT-AVConvert.lnk")
$location = "C:\Program Files\YT-AVConvert"

$pwsh_path = "$location\AVConvert.bat"
if ($shorcut.TargetPath -ne $pwsh_path) {
    $shortcut.TargetPath = $pwsh_path
    $shortcut.IconLocation = "$location\YTAVCIcon.ico"
    $shortcut.Save()
}